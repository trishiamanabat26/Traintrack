<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: admin_login.php");
    exit;
}

require '../config.php';

// Handle approval/rejection
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['resume_id'], $_POST['action'])) {
    $resume_id = intval($_POST['resume_id']);
    $action = $_POST['action'] === 'approve' ? 'Approved' : 'Rejected';

    $stmt = $conn->prepare("UPDATE resumes SET status = ? WHERE id = ?");
    $stmt->bind_param("si", $action, $resume_id);
    $stmt->execute();
}

// Fetch updated resumes
$resumes = $conn->query("SELECT * FROM resumes ORDER BY uploaded_at DESC");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard - TrainTrack</title>
    <link rel="stylesheet" href="dash.css">
    <style>
        /* General styles */
        body {
            font-family: Arial, sans-serif;
            background: #f7f9fb;
            margin: 0;
            padding: 40px;
        }

        h2 {
            text-align: center;
            color: #333;
        }

        a {
            color: #007bff;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }

        /* Logout button */
        .logout {
            float: right;
            background-color: #555;
            color: white;
            padding: 8px 16px;
            text-decoration: none;
            border-radius: 6px;
            margin-bottom: 10px;
        }

        .logout:hover {
            background-color: #333;
        }

        /* Table styling */
        table {
            border-collapse: collapse;
            width: 100%;
            margin-top: 25px;
            background: #fff;
            box-shadow: 0 4px 12px rgba(0,0,0,0.05);
            border-radius: 10px;
            overflow: hidden;
        }

        table, th, td {
            border: 1px solid #aaa;
        }

        th {
            background-color: #007bff;
            color: white;
        }

        th, td {
            padding: 12px;
            text-align: center;
        }

        /* Buttons */
        .btn {
            padding: 6px 12px;
            margin: 2px;
            border: none;
            border-radius: 4px;
            color: white;
            cursor: pointer;
            font-size: 14px;
        }

        .approve {
            background-color: #4CAF50;
        }

        .approve:hover {
            background-color: #3e8e41;
        }

        .reject {
            background-color: #f44336;
        }

        .reject:hover {
            background-color: #d32f2f;
        }
    </style>
</head>
<body>

<h2>TrainTrack Admin Dashboard</h2>

<a class="logout" href="logout.php">Logout</a>

<table>
    <thead>
        <tr>
            <th>File Name</th>
            <th>Student ID</th>
            <th>Uploaded At</th>
            <th>Status</th>
            <th>Download</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php if ($resumes->num_rows > 0): ?>
            <?php while ($row = $resumes->fetch_assoc()): ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['file_name']); ?></td>
                    <td><?php echo htmlspecialchars($row['student_id']); ?></td>
                    <td><?php echo htmlspecialchars($row['uploaded_at']); ?></td>
                    <td><?php echo htmlspecialchars($row['status']); ?></td>
                    <td><a href="../uploads/<?php echo urlencode($row['file_name']); ?>" download>Download</a></td>
                    <td>
                        <form method="POST" style="display:inline;">
                            <input type="hidden" name="resume_id" value="<?php echo $row['id']; ?>">
                            <button class="btn approve" type="submit" name="action" value="approve">Approve</button>
                        </form>
                        <form method="POST" style="display:inline;">
                            <input type="hidden" name="resume_id" value="<?php echo $row['id']; ?>">
                            <button class="btn reject" type="submit" name="action" value="reject">Reject</button>
                        </form>
                    </td>
                </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr>
                <td colspan="6">No resume submissions found.</td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>

</body>
</html>
