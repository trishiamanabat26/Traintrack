<?php
session_start();
require 'config.php';

$student_id = $_SESSION['student_id'];

if ($_FILES['resume']['error'] == 0) {
    $allowed = ['pdf', 'docx'];
    $ext = strtolower(pathinfo($_FILES['resume']['name'], PATHINFO_EXTENSION));

    if (!in_array($ext, $allowed)) {
        die("Invalid file type.");
    }

    $filename = $student_id . '_' . time() . '.' . $ext;
    move_uploaded_file($_FILES['resume']['tmp_name'], "uploads/$filename");

    $conn->query("DELETE FROM resumes WHERE student_id = '$student_id'");
    $stmt = $conn->prepare("INSERT INTO resumes (student_id, file_name, status) VALUES (?, ?, 'pending')");
    $stmt->bind_param("ss", $student_id, $filename);
    $stmt->execute();

    header("Location: dashboard.php");
} else {
    echo "File upload failed.";
}
