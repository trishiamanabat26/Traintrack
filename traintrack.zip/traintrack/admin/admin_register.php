<?php
session_start();
require '../config.php'; // your database connection

if (isset($_SESSION['admin_logged_in'])) {
    header("Location: dashboard.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    $confirm = $_POST['confirm_password'];

    if ($password !== $confirm) {
        $error = "Passwords do not match.";
    } else {
        // Check if username exists
        $stmt = $conn->prepare("SELECT * FROM admins WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $res = $stmt->get_result();

        if ($res->num_rows > 0) {
            $error = "Username already exists.";
        } else {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $insert = $conn->prepare("INSERT INTO admins (username, password) VALUES (?, ?)");
            $insert->bind_param("ss", $username, $hashed_password);
            if ($insert->execute()) {
                $_SESSION['admin_logged_in'] = true;
                header("Location: admin_login.php");
                exit;
            } else {
                $error = "Failed to register. Try again.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Admin Register - TrainTrack</title>
  <link rel="stylesheet" href="style.css"> <!-- Importing styles.css -->
</head>
<body>
<div class="container">
  <div class="login-card">
    <h2>Admin Register</h2>
    <?php if (isset($error)): ?>
      <p style="color:red; text-align:center;"><?php echo $error; ?></p>
    <?php endif; ?>
    <form method="POST">
      <label>Username</label>
      <input type="text" name="username" required>

      <label>Password</label>
      <input type="password" name="password" required>

      <label>Confirm Password</label>
      <input type="password" name="confirm_password" required>

      <button type="submit">Register</button>
    </form>

    <p style="text-align:center; margin-top:10px;">
      Already have an account? <a href="admin_login.php">Login here</a>
    </p>
  </div>
</div>
</body>
</html>
