<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: admin_login.php");
    exit;
}
require '../config.php';

$result = $conn->query("SELECT * FROM resumes ORDER BY uploaded_at DESC");
?>
<!-- HTML Table: file_name, student_id, uploaded_at, status -->
<!-- Add Approve/Reject forms and download links -->
