<?php
session_start();
if (!isset($_SESSION['student_id'])) {
    header("Location: index.php");
    exit;
}
require 'config.php';

$student_id = $_SESSION['student_id'];
$result = $conn->query("SELECT * FROM resumes WHERE student_id = '$student_id'");
$resume = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html>
<head>
  <title>Student Dashboard</title>
  <link rel="stylesheet" href="styles.css">
</head>
<body>
<div class="dashboard">
  <header>
    <h1>Welcome, <?= htmlspecialchars($student_id) ?></h1>
    <a href="logout.php" class="logout-btn">Logout</a>
  </header>

  <section class="upload-section">
    <h2>Upload Resume</h2>
    <form action="upload.php" method="POST" enctype="multipart/form-data">
      <input type="file" name="resume" accept=".pdf,.docx" required>
      <button type="submit">Upload</button>
    </form>
  </section>

  <section class="status-section">
    <h2>Application Status</h2>
    <?php if ($resume): ?>
      <div class="status-box <?= strtolower($resume['status']) ?>">
        <?= ucfirst($resume['status']) ?>
      </div>
      <p><a href="uploads/<?= htmlspecialchars($resume['file_name']) ?>" target="_blank">View Uploaded Resume</a></p>
    <?php else: ?>
      <p>No resume uploaded yet.</p>
    <?php endif; ?>
  </section>
</div>
</body>
</html>
